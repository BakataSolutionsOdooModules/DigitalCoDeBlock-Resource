// This file was automatically generated. Do not modify.
/* eslint-disable func-style */
/* eslint-disable require-jsdoc */
/* eslint-disable quotes */
/* eslint-disable quote-props */
/* eslint-disable dot-notation */
/* eslint-disable max-len */
function getInterfaceTranslations () {
    return {
        "en": {
            "ChuChubot.name": "EscornaBot",
            "ChuChubot.description": "EscornaBot desarrollado por Digital CodeSign.Incorpora bloques Scratch para manejar ChuChubot."
        },
        "ru": {
            "ChuChubot.name": "EscornaBot",
            "ChuChubot.description": "EscornaBot desarrollado por Digital CodeSign.Incorpora bloques Scratch para manejar ChuChubot."
        },
        "zh-cn": {
            "ChuChubot.name": "EscornaBot",
            "ChuChubot.description": "EscornaBot desarrollado por Digital CodeSign.Incorpora bloques Scratch para manejar ChuChubot."
        },
        "zh-tw": {
            "ChuChubot.name": "EscornaBot",
            "ChuChubot.description": "EscornaBot desarrollado por Digital CodeSign.Incorpora bloques Scratch para manejar ChuChubot."
        }
    }
    ;
}

function registerScratchExtensionTranslations () {
    return {};
}

function registerBlocksMessages (Blockly) {
    return Blockly;
}

if (typeof module !== 'undefined') {
    module.exports = {getInterfaceTranslations};
}
exports = registerScratchExtensionTranslations;
exports = registerBlocksMessages;
