// This file was automatically generated. Do not modify.
/* eslint-disable func-style */
/* eslint-disable require-jsdoc */
/* eslint-disable quotes */
/* eslint-disable quote-props */
/* eslint-disable dot-notation */
/* eslint-disable max-len */
function getInterfaceTranslations () {
    return {
        "en": {
            "deviceDemo.name": "Third Party Device Demo",
            "deviceDemo.description": "Un ejemplo mostrando como añadir una tarjeta externa mediante herencia de otra."
        },
        "ru": {
            "deviceDemo.name": "Third Party Device Demo",
            "deviceDemo.description": "An example showing how to add a third-party board by inheriting a built-in board."
        },
        "zh-cn": {
            "deviceDemo.name": "Third Party Device Demo",
            "deviceDemo.description": "An example showing how to add a third-party board by inheriting a built-in board."
        },
        "zh-tw": {
            "deviceDemo.name": "Third Party Device Demo",
            "deviceDemo.description": "An example showing how to add a third-party board by inheriting a built-in board."
        }
    }
    ;
}

function registerScratchExtensionTranslations () {
    return {};
}

function registerBlocksMessages (Blockly) {
    return Blockly;
}

if (typeof module !== 'undefined') {
    module.exports = {getInterfaceTranslations};
}
exports = registerScratchExtensionTranslations;
exports = registerBlocksMessages;
