// This file was automatically generated. Do not modify.
/* eslint-disable func-style */
/* eslint-disable require-jsdoc */
/* eslint-disable quotes */
/* eslint-disable quote-props */
/* eslint-disable dot-notation */
/* eslint-disable max-len */
function getInterfaceTranslations () {
    return {
        "en": {
            "MentorBit.name": "MentorBit",
            "MentorBit.description": "MentorBit desarrollado por Digital CodeSign.Incorpora bloques Scratch para manejar MentorBit."
        },
        "ru": {
            "MentorBit.name": "MentorBit",
            "ChuChubot.description": "MentorBit desarrollado por Digital CodeSign.Incorpora bloques Scratch para manejar MentorBit."
        },
        "zh-cn": {
            "MentorBit.name": "MentorBit",
            "ChuChubot.description": "MentorBit desarrollado por Digital CodeSign.Incorpora bloques Scratch para manejar MentorBit."
        },
        "zh-tw": {
            "MentorBit.name": "MentorBit",
            "ChuChubot.description": "MentorBit desarrollado por Digital CodeSign.Incorpora bloques Scratch para manejar MentorBit."
        }
    }
    ;
}

function registerScratchExtensionTranslations () {
    return {};
}

function registerBlocksMessages (Blockly) {
    return Blockly;
}

if (typeof module !== 'undefined') {
    module.exports = {getInterfaceTranslations};
}
exports = registerScratchExtensionTranslations;
exports = registerBlocksMessages;
